package com.example.fyp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Game1 extends AppCompatActivity{

    public int count=0;
    public int qutNo=3;
    public String[] qut = {"a", "2.14", "true"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game1);

        Chronometer game1Timer = (Chronometer) findViewById(R.id.game1Timer);
        game1Timer.start();

        TextView textQut = (TextView) findViewById(R.id.textQut);
        textQut.setText(qut[0]);

    }

}